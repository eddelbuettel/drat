
convolve <- function(a, b) {
    .Call(convolve_c, a, b)
}
