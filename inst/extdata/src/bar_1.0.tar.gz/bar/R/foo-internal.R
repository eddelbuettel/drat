.barfn <- function() "bar"
