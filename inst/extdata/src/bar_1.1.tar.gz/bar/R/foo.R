foo <- function(x) {
	max(x)
}
