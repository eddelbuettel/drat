.foofn <-
function() "foo"
