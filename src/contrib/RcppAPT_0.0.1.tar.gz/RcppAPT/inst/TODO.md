
## Things to add

- cleanup.sh

- configure (to test Debian system and lib-apt-pkg headers)

- roxygen headers in cpp

- functionality...
